package com.campusconnect.dto;

import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateProfileRequest {
    private String phone;
    private String guardianPhone;
    private String guardianEmail;
    private String profilePhotoUrl;
    private String portfolioUrl;
    private String githubUrl;
    private String linkedinUrl;
}
