package com.campusconnect.dto;

import com.campusconnect.model.ProjectStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateProjectRequest {
    private String title;
    private String domain;
    private String description;
    private String guideName;
    private String teamMembers;
    private String githubUrl;
    private String demoUrl;
    private ProjectStatus status;
}
